library(testthat)
library(lifecontingencies)
test_check("lifecontingencies")

